Sahan Ai Signal - বিল্ড করার নিয়ম (GitHub দিয়ে)

১) GitHub-এ নতুন রিপো বানাও (যেমন SahanAiSignal)।
২) এই জিপের ভেতরের সব ফাইল (.github ফোল্ডারসহ) রিপোতে আপলোড/পুশ করো।
৩) GitHub > Actions > "Build APK" চলবে। শেষ হলে Artifacts থেকে SahanAiSignal-apk ডাউনলোড করো।
৪) APK ইনস্টল করে অনুমতি দাও: অন্য অ্যাপের ওপর দেখানো + স্ক্রিন ক্যাপচার।

আগের AI-র লোগো বসাতে: app/src/main/res/drawable-nodpi/logo.png আর
mipmap-*/ic_launcher.png ফাইলগুলো তোমার লোগো দিয়ে বদলে দাও (একই নামে)।

বিল্ডে এরর এলে Actions-এর লগের লাল অংশটা কপি করে পাঠাও, ঠিক করে দেব।
