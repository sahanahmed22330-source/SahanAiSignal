package com.sahan.aisignal

import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign
import kotlin.math.sqrt

/** price scale: bigger = higher on chart */
data class Candle(val x: Float, val up: Boolean, val high: Float, val low: Float, val open: Float, val close: Float)

data class Eval(val total: Double, val maxAbs: Double, val items: List<Pair<String, Double>>)

data class Verdict(val up: Boolean, val confidence: Int, val reasons: List<String>, val candleCount: Int)

object Analyzer {

    private fun kind(p: Int): Int {
        val r = (p shr 16) and 0xFF
        val g = (p shr 8) and 0xFF
        val b = p and 0xFF
        if (g > 130 && g - r > 55 && g - b > 15 && r < 120) return 1
        if (r > 190 && r - g > 85 && r - b > 70 && g < 140) return 2
        return 0
    }

    /** Reads candles from chart pixels (green = up, red = down). */
    fun extract(px: IntArray, w: Int, h: Int, ignore: Rect?): List<Candle> {
        val colKind = IntArray(w)
        for (x in 0 until w) {
            var g = 0
            var r = 0
            for (y in 0 until h) {
                if (ignore != null && ignore.contains(x, y)) continue
                val k = kind(px[y * w + x])
                if (k == 1) g++ else if (k == 2) r++
            }
            colKind[x] = if (g >= 3 && g >= r) 1 else if (r >= 3) 2 else 0
        }
        val groups = ArrayList<IntArray>()
        var x = 0
        while (x < w) {
            val k = colKind[x]
            if (k == 0) { x++; continue }
            var e = x
            while (e + 1 < w && colKind[e + 1] == k) e++
            groups.add(intArrayOf(x, e, k))
            x = e + 1
        }
        val out = ArrayList<Candle>()
        if (groups.isEmpty()) return out
        val widths = groups.map { it[1] - it[0] + 1 }.sorted()
        val med = widths[widths.size / 2]
        val maxW = max(8, med * 3 + 2)

        for (gr in groups) {
            val gx0 = gr[0]
            val gx1 = gr[1]
            val k = gr[2]
            if (gx1 - gx0 + 1 > maxW) continue
            val rowCnt = IntArray(h)
            var top = Int.MAX_VALUE
            var bot = -1
            for (y in 0 until h) {
                var c = 0
                for (xx in gx0..gx1) {
                    if (ignore != null && ignore.contains(xx, y)) continue
                    if (kind(px[y * w + xx]) == k) c++
                }
                rowCnt[y] = c
                if (c > 0) {
                    if (y < top) top = y
                    if (y > bot) bot = y
                }
            }
            if (bot < 0 || bot - top < 2) continue
            var maxRow = 0
            for (y in top..bot) maxRow = max(maxRow, rowCnt[y])
            var bt = -1
            var bb = -1
            if (maxRow >= 3) {
                val thr = max(2, (maxRow * 0.6).toInt())
                for (y in top..bot) {
                    if (rowCnt[y] >= thr) {
                        if (bt < 0) bt = y
                        bb = y
                    }
                }
            } else {
                bt = top
                bb = bot
            }
            val up = k == 1
            val hi = (h - top).toFloat()
            val lo = (h - bot).toFloat()
            val bodyTop = (h - bt).toFloat()
            val bodyBot = (h - bb).toFloat()
            out.add(Candle((gx0 + gx1) / 2f, up, hi, lo, if (up) bodyBot else bodyTop, if (up) bodyTop else bodyBot))
        }
        out.sortBy { it.x }
        return if (out.size > 60) ArrayList(out.subList(out.size - 60, out.size)) else out
    }

    private fun ema(v: List<Double>, p: Int): List<Double> {
        val k = 2.0 / (p + 1)
        val o = ArrayList<Double>()
        var e = v[0]
        for (x in v) {
            e = x * k + e * (1 - k)
            o.add(e)
        }
        return o
    }

    /** Scores one frame. Positive = UP, negative = DOWN. */
    fun evaluate(cs: List<Candle>): Eval? {
        if (cs.size < 10) return null
        val n = cs.size
        val close = cs.map { it.close.toDouble() }
        val ranges = cs.map { (it.high - it.low).toDouble() }
        val atr = max(2.0, ranges.takeLast(14).average())
        val items = ArrayList<Pair<String, Double>>()
        fun add(name: String, v: Double) {
            if (v != 0.0) items.add(Pair(name, v))
        }

        // 1) trend (regression of last 12 closes)
        val m = min(12, n)
        val ys = close.takeLast(m)
        val xm = (m - 1) / 2.0
        val ym = ys.average()
        var num = 0.0
        var den = 0.0
        for (i in 0 until m) {
            num += (i - xm) * (ys[i] - ym)
            den += (i - xm) * (i - xm)
        }
        val slope = if (den == 0.0) 0.0 else num / den
        val trend = (slope / atr * 3.0).coerceIn(-2.0, 2.0)
        add(if (trend > 0) "ট্রেন্ড উপরের দিকে" else "ট্রেন্ড নিচের দিকে", trend)

        // 2) EMA cross
        val e5 = ema(close, 5)
        val e13 = ema(close, 13)
        val ed = ((e5.last() - e13.last()) / atr * 2.0).coerceIn(-1.5, 1.5)
        add(if (ed > 0) "EMA ক্রস উপরে" else "EMA ক্রস নিচে", ed)

        // 3) RSI
        val p = min(14, n - 1)
        var gain = 0.0
        var loss = 0.0
        for (i in n - p until n) {
            val d = close[i] - close[i - 1]
            if (d > 0) gain += d else loss -= d
        }
        val rsi = if (gain == 0.0 && loss == 0.0) 50.0 else if (loss == 0.0) 100.0 else 100.0 - 100.0 / (1.0 + gain / loss)
        val rv = when {
            rsi >= 75 -> -1.2
            rsi <= 25 -> 1.2
            rsi in 55.0..75.0 -> 0.3
            rsi in 25.0..45.0 -> -0.3
            else -> 0.0
        }
        add("RSI ${rsi.toInt()}" + (if (rv > 0) " (বাড়ার সম্ভাবনা)" else " (কমার সম্ভাবনা)"), rv)

        // 4) MACD
        if (n >= 26) {
            val e12 = ema(close, 12)
            val e26 = ema(close, 26)
            val ml = e12.indices.map { e12[it] - e26[it] }
            val sg = ema(ml, 9)
            val h1 = ml[n - 1] - sg[n - 1]
            val h0 = ml[n - 2] - sg[n - 2]
            val mv = (if (h1 > 0) 0.6 else -0.6) + (if (h1 > h0) 0.4 else -0.4)
            add(if (mv > 0) "MACD বুলিশ" else "MACD বেয়ারিশ", mv)
        }

        // 5) Bollinger
        val bw = close.takeLast(min(20, n))
        val sma = bw.average()
        val sd = sqrt(bw.map { (it - sma) * (it - sma) }.average())
        if (sd > 0.5) {
            val z = (close.last() - sma) / sd
            if (abs(z) > 1.9) add(if (z > 0) "বলিঞ্জার উপরে ছুঁয়েছে (ফেরার সম্ভাবনা)" else "বলিঞ্জার নিচে ছুঁয়েছে (ফেরার সম্ভাবনা)", -sign(z))
            else add(if (z > 0) "দাম মাঝের লাইনের উপরে" else "দাম মাঝের লাইনের নিচে", z * 0.35)
        }

        // 6) momentum of last 3 candles
        val mom = ((close[n - 1] - close[n - 4]) / atr * 0.7).coerceIn(-1.5, 1.5)
        add(if (mom > 0) "শেষ ৩ ক্যান্ডেলে গতি উপরে" else "শেষ ৩ ক্যান্ডেলে গতি নিচে", mom)

        // 7) candle patterns
        val c = cs[n - 1]
        val pv = cs[n - 2]
        val body = abs(c.close - c.open).toDouble()
        val rng = max(1.0, (c.high - c.low).toDouble())
        val uw = (c.high - max(c.open, c.close)).toDouble()
        val lw = (min(c.open, c.close) - c.low).toDouble()
        val dir = if (c.up) 1.0 else -1.0
        var doji = false
        if (rng >= 0.5 * atr) {
            if (lw >= 0.55 * rng && body <= 0.35 * rng) {
                add("Hammer (নিচে লম্বা উইক)", if (trend < 0) 1.9 else 1.4)
            } else if (uw >= 0.55 * rng && body <= 0.35 * rng) {
                add("Shooting Star (উপরে লম্বা উইক)", if (trend > 0) -1.9 else -1.4)
            } else if (body <= 0.1 * rng) {
                doji = true
            } else if (uw >= 0.4 * rng) {
                add("উপরের উইক বড় (বিক্রির চাপ)", -0.7)
            } else if (lw >= 0.4 * rng) {
                add("নিচের উইক বড় (কেনার চাপ)", 0.7)
            }
            if (body >= 0.7 * rng && body >= 1.2 * atr) add(if (c.up) "শক্তিশালী সবুজ ক্যান্ডেল" else "শক্তিশালী লাল ক্যান্ডেল", 0.8 * dir)
        }
        val tol = 0.1 * atr
        val pbody = abs(pv.close - pv.open).toDouble()
        if (!pv.up && c.up && c.close >= pv.open - tol && c.open <= pv.close + tol && body > pbody) add("Bullish Engulfing", 1.5)
        if (pv.up && !c.up && c.close <= pv.open + tol && c.open >= pv.close - tol && body > pbody) add("Bearish Engulfing", -1.5)

        var st = 0
        for (i in n - 1 downTo 0) {
            if (cs[i].up == c.up) st++ else break
        }
        if (st >= 6) add("একই রঙের $st ক্যান্ডেল, উল্টানোর ঝুঁকি", -dir * 0.8)
        else if (st >= 2) add("টানা $st ক্যান্ডেল একই দিকে", dir * 0.2 * st)

        // 8) support / resistance
        if (n >= 12) {
            val look = cs.subList(max(0, n - 40), n - 2)
            val res = look.maxOf { it.high }.toDouble()
            val sup = look.minOf { it.low }.toDouble()
            val last = close.last()
            val near = 0.7 * atr
            if (last >= res - near && last <= res + 0.2 * atr) add("রেজিস্ট্যান্সের কাছে", -1.0)
            else if (last > res + 0.2 * atr) add("রেজিস্ট্যান্স ব্রেকআউট", 0.8)
            if (last <= sup + near && last >= sup - 0.2 * atr) add("সাপোর্টের কাছে", 1.0)
            else if (last < sup - 0.2 * atr) add("সাপোর্ট ব্রেকডাউন", -0.8)
        }

        var total = 0.0
        var maxAbs = 0.0
        for (entry in items) {
            total += entry.second
            maxAbs += abs(entry.second)
        }
        if (doji) {
            maxAbs += 1.0
            items.add(Pair("ডোজি (অনিশ্চিত)", 0.0))
        }
        return Eval(total, maxAbs, items)
    }

    fun combine(evals: List<Eval>, candleCount: Int): Verdict {
        val t = evals.sumOf { it.total }
        val m = max(0.001, evals.sumOf { it.maxAbs })
        val up = t >= 0
        val agree = evals.count { (it.total >= 0) == up }.toDouble() / evals.size
        val ratio = abs(t) / m
        val conf = (50 + 45 * ratio * (0.5 + 0.5 * agree)).toInt().coerceIn(51, 95)
        val items = evals.last().items.sortedByDescending { abs(it.second) }
        val rs = items.filter { it.second != 0.0 && (it.second >= 0) == up }.take(3).map { it.first }
        return Verdict(up, conf, rs, candleCount)
    }
}
