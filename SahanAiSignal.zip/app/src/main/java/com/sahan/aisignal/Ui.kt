package com.sahan.aisignal

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.widget.LinearLayout
import android.widget.TextView

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun tfLabel(tf: Int): String = if (tf < 60) "$tf সেকেন্ড" else "${tf / 60} মিনিট"

fun rounded(color: Int, radius: Float, stroke: Int = 0, strokeColor: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radius
    if (stroke > 0) g.setStroke(stroke, strokeColor)
    return g
}

fun gradient(c1: Int, c2: Int, radius: Float): GradientDrawable {
    val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2))
    g.cornerRadius = radius
    return g
}

fun appBg(): GradientDrawable = GradientDrawable(
    GradientDrawable.Orientation.TL_BR,
    intArrayOf(0xFF070B24.toInt(), 0xFF1A1050.toInt(), 0xFF2B0B4A.toInt())
)

fun Context.tv(s: String, sp: Float, color: Int, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = s
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    return t
}

fun Context.card(): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.setPadding(dp(16), dp(14), dp(16), dp(14))
    c.background = rounded(0x1FFFFFFF, dp(18).toFloat(), dp(1), 0x33FFFFFF)
    return c
}
