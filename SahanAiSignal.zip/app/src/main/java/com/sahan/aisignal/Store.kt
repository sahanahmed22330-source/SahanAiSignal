package com.sahan.aisignal

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Rec(val time: Long, val tf: Int, val up: Boolean, val conf: Int, val result: Int)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("sahan_ai_signal", Context.MODE_PRIVATE)

    fun tf(c: Context): Int = p(c).getInt("tf", 60)
    fun setTf(c: Context, v: Int) { p(c).edit().putInt("tf", v).apply() }

    fun auto(c: Context): Boolean = p(c).getBoolean("auto", false)
    fun setAuto(c: Context, v: Boolean) { p(c).edit().putBoolean("auto", v).apply() }

    fun top(c: Context): Int = p(c).getInt("top", 12)
    fun setTop(c: Context, v: Int) { p(c).edit().putInt("top", v).apply() }

    fun bottom(c: Context): Int = p(c).getInt("bottom", 62)
    fun setBottom(c: Context, v: Int) { p(c).edit().putInt("bottom", v).apply() }

    // clock offset in tenths of a second
    fun offset(c: Context): Int = p(c).getInt("offset", 0)
    fun setOffset(c: Context, v: Int) { p(c).edit().putInt("offset", v).apply() }

    @Synchronized
    fun history(c: Context): MutableList<Rec> {
        val out = ArrayList<Rec>()
        try {
            val a = JSONArray(p(c).getString("hist", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Rec(o.getLong("t"), o.getInt("tf"), o.getBoolean("up"), o.getInt("c"), o.getInt("r")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun save(c: Context, l: List<Rec>) {
        val a = JSONArray()
        for (r in l) {
            a.put(JSONObject().put("t", r.time).put("tf", r.tf).put("up", r.up).put("c", r.conf).put("r", r.result))
        }
        p(c).edit().putString("hist", a.toString()).apply()
    }

    @Synchronized
    fun add(c: Context, r: Rec) {
        val l = history(c)
        l.add(0, r)
        while (l.size > 300) l.removeAt(l.size - 1)
        save(c, l)
    }

    @Synchronized
    fun setResult(c: Context, time: Long, res: Int) {
        val l = history(c)
        for (i in l.indices) {
            if (l[i].time == time) l[i] = l[i].copy(result = res)
        }
        save(c, l)
    }

    @Synchronized
    fun clear(c: Context) { p(c).edit().putString("hist", "[]").apply() }
}
