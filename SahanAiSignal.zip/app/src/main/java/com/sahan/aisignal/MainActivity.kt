package com.sahan.aisignal

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var startBtn: TextView
    private val tfViews = ArrayList<Pair<Int, TextView>>()
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(appBg())

        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(36), dp(18), dp(30))
        sv.addView(col)
        setContentView(sv)

        val white = 0xFFFFFFFF.toInt()
        val cyan = 0xFF00E5FF.toInt()

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        val logoLp = LinearLayout.LayoutParams(dp(110), dp(110))
        logoLp.gravity = Gravity.CENTER_HORIZONTAL
        col.addView(logo, logoLp)

        val title = tv("Sahan Ai Signal", 26f, white, true)
        title.gravity = Gravity.CENTER
        col.addView(title, full())
        val sub = tv("Live Candle AI Analyzer", 13f, cyan)
        sub.gravity = Gravity.CENTER
        col.addView(sub, full())

        // --- candle time
        val c1 = card()
        c1.addView(tv("ক্যান্ডেল টাইম", 15f, white, true))
        c1.addView(tv("Quotex-এ যে ক্যান্ডেল টাইম ব্যবহার করছ সেটা বেছে নাও", 11f, 0xAAFFFFFF.toInt()))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(10), 0, 0)
        for (tf in intArrayOf(5, 10, 60)) {
            val t = tv(tfLabel(tf), 14f, white, true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(12), 0, dp(12))
            t.setOnClickListener {
                Store.setTf(this, tf)
                refreshTf()
            }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(4), 0, dp(4), 0)
            row.addView(t, lp)
            tfViews.add(Pair(tf, t))
        }
        c1.addView(row)
        col.addView(c1, cardLp())
        refreshTf()

        // --- auto
        val c2 = card()
        val sw = Switch(this)
        sw.text = "অটো সিগনাল"
        sw.setTextColor(white)
        sw.textSize = 16f
        sw.isChecked = Store.auto(this)
        sw.setOnCheckedChangeListener { _, v -> Store.setAuto(this, v) }
        c2.addView(sw)
        c2.addView(tv("অন থাকলে ক্যান্ডেল শেষ হওয়ার ঠিক আগে নিজে নিজে পরের ক্যান্ডেলের সিগনাল দেবে। বাটন Quotex-এর ওপর বসিয়ে রাখো।", 11f, 0xAAFFFFFF.toInt()))
        col.addView(c2, cardLp())

        // --- settings
        val c3 = card()
        c3.addView(tv("সেটিং", 15f, white, true))
        slider(c3, "চার্ট এলাকার উপরের সীমা", 0, 40, Store.top(this), { "$it%" }) { Store.setTop(this, it) }
        slider(c3, "চার্ট এলাকার নিচের সীমা", 40, 90, Store.bottom(this), { "$it%" }) { Store.setBottom(this, it) }
        slider(c3, "ঘড়ি সামঞ্জস্য", -30, 30, Store.offset(this), { String.format(Locale.US, "%+.1f সে.", it / 10.0) }) { Store.setOffset(this, it) }
        c3.addView(tv("চার্ট এলাকায় শুধু ক্যান্ডেল থাকবে, নিচের UP/DOWN বাটন নয়। বাটনের টাইমার Quotex-এর টাইমারের সাথে না মিললে ঘড়ি সামঞ্জস্য ঠিক করো।", 11f, 0xAAFFFFFF.toInt()))
        col.addView(c3, cardLp())

        // --- start / stop
        startBtn = tv("", 17f, white, true)
        startBtn.gravity = Gravity.CENTER
        startBtn.setPadding(0, dp(16), 0, dp(16))
        startBtn.setOnClickListener {
            if (OverlayService.running) {
                stopService(Intent(this, OverlayService::class.java))
                handler.postDelayed({ refreshStart() }, 400)
            } else {
                startFlow()
            }
        }
        val slp = cardLp()
        slp.topMargin = dp(18)
        col.addView(startBtn, slp)

        val hist = tv("📊  ফলাফল ও হিস্টোরি", 15f, white, true)
        hist.gravity = Gravity.CENTER
        hist.setPadding(0, dp(14), 0, dp(14))
        hist.background = rounded(0x22FFFFFF, dp(16).toFloat(), dp(1), 0x55FFFFFF)
        hist.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        col.addView(hist, cardLp())

        val c4 = card()
        c4.addView(tv("কীভাবে চালাবে", 14f, white, true))
        c4.addView(tv("১) ক্যান্ডেল টাইম বেছে 'ফ্লোটিং বাটন চালু করো' চাপো\n২) Quotex খুলে ক্যান্ডেল চার্ট রাখো, বাটন এক পাশে সরাও\n৩) রানিং ক্যান্ডেল শেষ হতে ৫-৭ সেকেন্ড বাকি থাকতে বাটন চাপো\n৪) পপআপে UP/DOWN দেখে ট্রেড নাও, তারপর ✕ চেপে পপআপ সরাও\n৫) ফলাফল অ্যাপের হিস্টোরিতে জিত/হার মার্ক করো", 12f, 0xCCFFFFFF.toInt()))
        c4.addView(tv("⚠ কোনো অ্যাপই ১০০% সঠিক সিগনাল দিতে পারে না। আগে ডেমোতে পরীক্ষা করো, যা হারাতে পারবে না তা দিয়ে ট্রেড করো না।", 11f, 0xFFFFCC80.toInt()))
        col.addView(c4, cardLp())
    }

    private fun full() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun cardLp(): LinearLayout.LayoutParams {
        val lp = full()
        lp.topMargin = dp(14)
        return lp
    }

    private fun refreshTf() {
        val cur = Store.tf(this)
        for ((tf, t) in tfViews) {
            t.background = if (tf == cur) gradient(0xFF00B8D4.toInt(), 0xFF7C4DFF.toInt(), dp(12).toFloat())
            else rounded(0x22FFFFFF, dp(12).toFloat(), dp(1), 0x44FFFFFF)
        }
    }

    private fun refreshStart() {
        if (OverlayService.running) {
            startBtn.text = "■  ফ্লোটিং বাটন বন্ধ করো"
            startBtn.background = gradient(0xFFFF1744.toInt(), 0xFFAD1457.toInt(), dp(16).toFloat())
        } else {
            startBtn.text = "▶  ফ্লোটিং বাটন চালু করো"
            startBtn.background = gradient(0xFF00C853.toInt(), 0xFF00B8D4.toInt(), dp(16).toFloat())
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStart()
    }

    private fun slider(card: LinearLayout, title: String, min: Int, max: Int, cur: Int, fmt: (Int) -> String, save: (Int) -> Unit) {
        val label = tv("$title: ${fmt(cur)}", 12f, 0xFFFFFFFF.toInt())
        label.setPadding(0, dp(10), 0, 0)
        card.addView(label)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                val v = p + min
                label.text = "$title: ${fmt(v)}"
                save(v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        card.addView(sb)
    }

    private fun startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "'অন্য অ্যাপের ওপর দেখানো' অনুমতি দাও, তারপর আবার চাপো", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java)
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            handler.postDelayed({ refreshStart() }, 700)
            Toast.makeText(this, "চালু হয়েছে! এখন Quotex খুলো।", Toast.LENGTH_SHORT).show()
        }
    }
}
