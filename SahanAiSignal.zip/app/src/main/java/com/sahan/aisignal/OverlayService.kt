package com.sahan.aisignal

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false
    }

    private class Frame(
        val pix: IntArray, val w: Int, val h: Int, val ignore: Rect,
        val lower: IntArray?, val lw: Int, val lh: Int
    )

    private class Ocr {
        val latch = CountDownLatch(1)
        @Volatile
        var text: String = ""
    }

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var sw = 0
    private var sh = 0
    private var btn: FrameLayout? = null
    private var btnLp: WindowManager.LayoutParams? = null
    private var timerTv: TextView? = null
    private var popup: View? = null
    private var cache: Frame? = null
    private var lastAutoStart = -1L

    @Volatile
    private var scanning = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra("data", Intent::class.java)
        else i?.getParcelableExtra("data")

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_NOT_STICKY
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = readData(intent)
        startFg()
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            screenSize()
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpm.getMediaProjection(code, data)
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    ui.post { stopSelf() }
                }
            }, ui)
            projection = mp
            val rd = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
            reader = rd
            vd = mp.createVirtualDisplay(
                "sahan_ai", sw, sh, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, null
            )
            createButton()
            running = true
            ui.post(tick)
        } catch (e: Throwable) {
            Toast.makeText(this, "স্ক্রিন ক্যাপচার চালু হয়নি: " + e.message, Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val ch = "sahan_ai"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(ch, "Sahan Ai Signal", NotificationManager.IMPORTANCE_LOW))
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this)
        val n = b.setContentTitle("Sahan Ai Signal চালু আছে")
            .setContentText("ফ্লোটিং বাটন চাপলে সিগনাল পাবে")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    @Suppress("DEPRECATION")
    private fun screenSize() {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            sw = b.width()
            sh = b.height()
        } else {
            val m = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(m)
            sw = m.widthPixels
            sh = m.heightPixels
        }
    }

    @Suppress("DEPRECATION")
    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    // ---------------------------------------------------------------- UI

    private fun drag(v: View, lp: WindowManager.LayoutParams, onTap: (() -> Unit)?) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = ox + dx.toInt()
                        lp.y = oy + dy.toInt()
                        try { wm.updateViewLayout(v, lp) } catch (ex: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke()
                    true
                }
                else -> false
            }
        }
    }

    private fun createButton() {
        val root = FrameLayout(this)
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        val llp = FrameLayout.LayoutParams(dp(64), dp(64), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        llp.topMargin = dp(10)
        root.addView(logo, llp)

        val x = tv("✕", 12f, 0xFFFFFFFF.toInt(), true)
        x.gravity = Gravity.CENTER
        x.background = rounded(0xFFE53935.toInt(), dp(12).toFloat())
        x.setOnClickListener { stopSelf() }
        root.addView(x, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.TOP or Gravity.END))

        val t = tv("--", 12f, 0xFFFFFFFF.toInt(), true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(8), 0, dp(8), 0)
        t.background = rounded(0xCC0B1030.toInt(), dp(11).toFloat())
        root.addView(t, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, dp(22), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        timerTv = t

        val lp = WindowManager.LayoutParams(
            dp(84), dp(96), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = (sh * 0.30).toInt()
        drag(root, lp) { if (!scanning) startScan() }
        wm.addView(root, lp)
        btn = root
        btnLp = lp
    }

    private fun hidePopup() {
        popup?.let {
            try { wm.removeView(it) } catch (e: Exception) { }
        }
        popup = null
    }

    private fun showPopup(v: Verdict?, err: String?, expiry: String?) {
        hidePopup()
        val tf = Store.tf(this)
        val up = v?.up ?: true
        val c1 = if (v == null) 0xFF4A148C.toInt() else if (up) 0xFF00C853.toInt() else 0xFFFF1744.toInt()
        val c2 = if (v == null) 0xFF1A237E.toInt() else if (up) 0xFF00695C.toInt() else 0xFFAD1457.toInt()
        val white = 0xFFFFFFFF.toInt()

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(16), dp(10), dp(16), dp(14))
        val bg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2))
        bg.cornerRadius = dp(22).toFloat()
        bg.setStroke(dp(2), 0xCCFFFFFF.toInt())
        card.background = bg

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val lg = ImageView(this)
        lg.setImageResource(R.drawable.logo)
        head.addView(lg, LinearLayout.LayoutParams(dp(26), dp(26)))
        head.addView(tv("  Sahan Ai Signal", 13f, white, true), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val x = tv("✕", 14f, white, true)
        x.gravity = Gravity.CENTER
        x.background = rounded(0x55000000, dp(15).toFloat())
        x.setOnClickListener { hidePopup() }
        head.addView(x, LinearLayout.LayoutParams(dp(30), dp(30)))
        card.addView(head)

        if (v == null) {
            val e = tv(err ?: "ত্রুটি", 14f, white)
            e.setPadding(0, dp(8), 0, 0)
            card.addView(e)
        } else {
            val big = tv(if (up) "▲  UP" else "▼  DOWN", 38f, white, true)
            big.gravity = Gravity.CENTER
            card.addView(big, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            val sub = tv("পরের ${tfLabel(tf)}-এর ক্যান্ডেল • কনফিডেন্স ${v.confidence}%", 12f, white)
            sub.gravity = Gravity.CENTER
            card.addView(sub, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

            val bar = LinearLayout(this)
            bar.orientation = LinearLayout.HORIZONTAL
            bar.background = rounded(0x44000000, dp(4).toFloat())
            val fill = View(this)
            fill.background = rounded(white, dp(4).toFloat())
            bar.addView(fill, LinearLayout.LayoutParams(0, dp(8), v.confidence.toFloat()))
            bar.addView(View(this), LinearLayout.LayoutParams(0, dp(8), (100 - v.confidence).toFloat()))
            val blp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(8))
            blp.topMargin = dp(6)
            blp.bottomMargin = dp(8)
            card.addView(bar, blp)

            for (r in v.reasons) card.addView(tv("• $r", 12f, 0xEEFFFFFF.toInt()))
            if (expiry != null) card.addView(tv("Quotex ট্রেড টাইম (পড়া হয়েছে): $expiry", 11f, 0xFFFFF59D.toInt()))
            val d = tv("কোনো সিগনালই ১০০% নিশ্চিত নয়", 10f, 0xAAFFFFFF.toInt())
            d.setPadding(0, dp(6), 0, 0)
            card.addView(d)
        }

        val w = dp(290)
        val lp = WindowManager.LayoutParams(
            w, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (sw - w) / 2
        lp.y = dp(60)
        drag(card, lp, null)
        try {
            wm.addView(card, lp)
            popup = card
        } catch (e: Exception) { }
    }

    // ---------------------------------------------------------------- timing

    private fun scanMs(tfMs: Long): Long = when {
        tfMs <= 5000L -> 1200L
        tfMs <= 10000L -> 2500L
        else -> 3500L
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val ctx = this@OverlayService
            val tfMs = Store.tf(ctx) * 1000L
            val now = System.currentTimeMillis() + Store.offset(ctx) * 100L
            val pos = now % tfMs
            val rem = tfMs - pos
            val start = now - pos
            if (!scanning) {
                timerTv?.text = if (tfMs <= 10000L) String.format(Locale.US, "%.1fs", rem / 1000.0)
                else String.format(Locale.US, "%d:%02d", rem / 60000, (rem / 1000) % 60)
            }
            if (Store.auto(ctx) && !scanning) {
                val trigger = scanMs(tfMs) + 1500L
                if (rem <= trigger && rem > 300L && start != lastAutoStart) {
                    lastAutoStart = start
                    startScan()
                }
            }
            ui.postDelayed(this, 100)
        }
    }

    // ---------------------------------------------------------------- capture

    private fun readRegion(img: Image, x0: Int, y0: Int, w: Int, h: Int): IntArray {
        val pl = img.planes[0]
        val buf = pl.buffer
        val rs = pl.rowStride
        val ps = pl.pixelStride
        val out = IntArray(w * h)
        val row = ByteArray(w * ps)
        for (r in 0 until h) {
            buf.position((y0 + r) * rs + x0 * ps)
            buf.get(row, 0, w * ps)
            var o = r * w
            var i = 0
            for (c in 0 until w) {
                out[o++] = (0xFF shl 24) or
                    ((row[i].toInt() and 0xFF) shl 16) or
                    ((row[i + 1].toInt() and 0xFF) shl 8) or
                    (row[i + 2].toInt() and 0xFF)
                i += ps
            }
        }
        return out
    }

    private fun grab(topPct: Int, botPct: Int, rect: Rect, wantLower: Boolean): Frame? {
        val r = reader ?: return null
        var img: Image? = null
        val end = SystemClock.uptimeMillis() + 600
        while (img == null && SystemClock.uptimeMillis() < end) {
            img = try { r.acquireLatestImage() } catch (e: Exception) { null }
            if (img == null) Thread.sleep(25)
        }
        if (img == null) return cache
        try {
            val iw = img.width
            val ih = img.height
            val cw = (iw * 0.86).toInt()
            val y0 = ih * topPct / 100
            val y1 = ih * botPct / 100
            val ch = (y1 - y0).coerceAtLeast(60)
            val pix = readRegion(img, 0, y0, cw, ch)
            var lower: IntArray? = null
            var lh = 0
            if (wantLower) {
                val ly = (ih * 0.55).toInt()
                lh = ih - ly
                lower = readRegion(img, 0, ly, iw, lh)
            }
            val ig = Rect(rect.left, rect.top - y0, rect.right, rect.bottom - y0)
            val f = Frame(pix, cw, ch, ig, lower, iw, lh)
            cache = f
            return f
        } finally {
            img.close()
        }
    }

    private fun startOcr(px: IntArray, w: Int, h: Int): Ocr {
        val o = Ocr()
        try {
            val bmp = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                .process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener {
                    o.text = it.text
                    o.latch.countDown()
                }
                .addOnFailureListener { o.latch.countDown() }
        } catch (e: Throwable) {
            o.latch.countDown()
        }
        return o
    }

    private fun parseExpiry(t: String): String? {
        val re = Regex("""(\d{1,2}):(\d{2})(?::(\d{2}))?""")
        for (m in re.findAll(t)) {
            val a = m.groupValues[1].toInt()
            val b = m.groupValues[2].toInt()
            val c = m.groupValues[3]
            val sec = if (c.isNotEmpty()) a * 3600 + b * 60 + c.toInt() else a * 60 + b
            if (sec in 5..900) {
                return if (sec < 60) "$sec সেকেন্ড"
                else if (sec % 60 == 0) "${sec / 60} মিনিট"
                else "${sec / 60} মিনিট ${sec % 60} সেকেন্ড"
            }
        }
        return null
    }

    private fun buttonRect(): Rect {
        val l = btnLp ?: return Rect(0, 0, 0, 0)
        return Rect(l.x - dp(4), l.y - dp(4), l.x + l.width + dp(4), l.y + l.height + dp(4))
    }

    private fun startScan() {
        if (scanning) return
        scanning = true
        val tf = Store.tf(this)
        val sd = scanMs(tf * 1000L)
        val top = Store.top(this)
        val bot = Store.bottom(this)
        val rect = buttonRect()
        hidePopup()
        timerTv?.text = "স্ক্যান…"

        worker.execute {
            var verdict: Verdict? = null
            var err: String? = null
            var expiry: String? = null
            try {
                val evals = ArrayList<Eval>()
                var candleN = 0
                var ocr: Ocr? = null
                var first = true
                val t0 = SystemClock.uptimeMillis()
                while (true) {
                    val el = SystemClock.uptimeMillis() - t0
                    if (el >= sd && evals.size >= 1) break
                    if (el > sd + 2000) break
                    val f = grab(top, bot, rect, first)
                    if (f == null) {
                        Thread.sleep(50)
                        continue
                    }
                    if (first) {
                        first = false
                        val lo = f.lower
                        if (lo != null) ocr = startOcr(lo, f.lw, f.lh)
                    }
                    val cs = Analyzer.extract(f.pix, f.w, f.h, f.ignore)
                    candleN = cs.size
                    val ev = Analyzer.evaluate(cs)
                    if (ev != null) evals.add(ev)
                    if (evals.size >= 14) break
                    Thread.sleep(120)
                }
                if (evals.isEmpty()) {
                    err = "ক্যান্ডেল চার্ট পাওয়া যায়নি (পাওয়া গেছে: $candleN)।\nQuotex-এ ক্যান্ডেল চার্ট খোলা রাখো, জুম করে ক্যান্ডেল বড় করো, আর অ্যাপের 'চার্ট এলাকা' সেটিং ঠিক করো।"
                } else {
                    verdict = Analyzer.combine(evals, candleN)
                }
                val o = ocr
                if (o != null) {
                    o.latch.await(900, TimeUnit.MILLISECONDS)
                    expiry = parseExpiry(o.text)
                }
            } catch (e: Throwable) {
                err = "স্ক্যান ব্যর্থ: " + e.message
            }
            val fv = verdict
            val fe = err
            val fx = expiry
            ui.post {
                scanning = false
                if (running) {
                    if (fv != null) Store.add(this, Rec(System.currentTimeMillis(), tf, fv.up, fv.confidence, 0))
                    showPopup(fv, fe, fx)
                }
            }
        }
    }

    override fun onDestroy() {
        running = false
        ui.removeCallbacksAndMessages(null)
        hidePopup()
        btn?.let {
            try { wm.removeView(it) } catch (e: Exception) { }
        }
        btn = null
        try { vd?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        worker.shutdownNow()
        super.onDestroy()
    }
}
