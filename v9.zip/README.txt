Sahan Ai Signal - build with GitHub Actions.
Upload the newest vN.zip (v4.zip, v5.zip ...) to the repo root; the workflow unzips the highest version and builds the APK.
To use your old AI logo: replace app/src/main/res/drawable-nodpi/logo.png and the mipmap-*/ic_launcher.png files.
