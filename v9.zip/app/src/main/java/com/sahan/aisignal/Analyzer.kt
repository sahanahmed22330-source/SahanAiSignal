package com.sahan.aisignal

import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign
import kotlin.math.sqrt

/** price scale: bigger = higher on chart */
data class Candle(val x: Float, val up: Boolean, val high: Float, val low: Float, val open: Float, val close: Float)

data class Item(val key: String, val label: String, val v: Double)

data class Eval(val total: Double, val maxAbs: Double, val items: List<Item>, val flags: List<String>, val groups: DoubleArray)

data class Verdict(
    val up: Boolean, val confidence: Int, val reasons: List<String>, val candleCount: Int,
    val keys: List<String>, val warnings: List<String>, val change: Boolean
)

object Analyzer {

    /** learned multipliers per factor (from win/loss marks) */
    @Volatile
    var weights: Map<String, Double> = emptyMap()

    // factor families: 0 = trend-following, 1 = oscillators (reversal), 2 = candle patterns, 3 = support/resistance/structure
    private val CAPS = doubleArrayOf(3.5, 2.5, 3.0, 2.5)

    private fun groupOf(key: String): Int = when (key) {
        "trend", "ema", "macd", "mom", "btrend", "pullback", "struct" -> 0
        "rsi", "boll", "stoch", "cci", "willr" -> 1
        "sr", "touches", "dbl", "fib" -> 3
        else -> 2
    }

    private fun kind(p: Int): Int {
        val r = (p shr 16) and 0xFF
        val g = (p shr 8) and 0xFF
        val b = p and 0xFF
        if (g > 130 && g - r > 55 && g - b > 15 && r < 120) return 1
        if (r > 190 && r - g > 85 && r - b > 70 && g < 140) return 2
        return 0
    }

    /** Reads candles from chart pixels (green = up, red = down). */
    private fun ign(l: List<Rect>, x: Int, y: Int): Boolean {
        for (r in l) if (r.contains(x, y)) return true
        return false
    }

    fun extract(px: IntArray, w: Int, h: Int, ignore: List<Rect>): List<Candle> {
        val colKind = IntArray(w)
        var colored = 0L
        for (x in 0 until w) {
            var g = 0
            var r = 0
            for (y in 0 until h) {
                if (ign(ignore, x, y)) continue
                val k = kind(px[y * w + x])
                if (k == 1) g++ else if (k == 2) r++
                if (k != 0) colored++
            }
            colKind[x] = if (g >= 3 && g >= r) 1 else if (r >= 3) 2 else 0
        }
        // a real chart has only a little green/red; wallpapers, photos and big banners have a lot
        if (colored > 0.25 * w * h) return ArrayList()
        val groups = ArrayList<IntArray>()
        var x = 0
        while (x < w) {
            val k = colKind[x]
            if (k == 0) { x++; continue }
            var e = x
            while (e + 1 < w && colKind[e + 1] == k) e++
            groups.add(intArrayOf(x, e, k))
            x = e + 1
        }
        val out = ArrayList<Candle>()
        if (groups.isEmpty()) return out
        val widths = groups.map { it[1] - it[0] + 1 }.sorted()
        val med = widths[widths.size / 2]
        val maxW = max(8, med * 3 + 2)

        for (gr in groups) {
            val gx0 = gr[0]
            val gx1 = gr[1]
            val k = gr[2]
            if (gx1 - gx0 + 1 > maxW) continue
            val rowCnt = IntArray(h)
            var top = Int.MAX_VALUE
            var bot = -1
            for (y in 0 until h) {
                var c = 0
                for (xx in gx0..gx1) {
                    if (ign(ignore, xx, y)) continue
                    if (kind(px[y * w + xx]) == k) c++
                }
                rowCnt[y] = c
                if (c > 0) {
                    if (y < top) top = y
                    if (y > bot) bot = y
                }
            }
            if (bot < 0 || bot - top < 2) continue
            var maxRow = 0
            for (y in top..bot) maxRow = max(maxRow, rowCnt[y])
            var bt = -1
            var bb = -1
            if (maxRow >= 3) {
                val thr = max(2, (maxRow * 0.6).toInt())
                for (y in top..bot) {
                    if (rowCnt[y] >= thr) {
                        if (bt < 0) bt = y
                        bb = y
                    }
                }
            } else {
                bt = top
                bb = bot
            }
            val up = k == 1
            val hi = (h - top).toFloat()
            val lo = (h - bot).toFloat()
            val bodyTop = (h - bt).toFloat()
            val bodyBot = (h - bb).toFloat()
            out.add(Candle((gx0 + gx1) / 2f, up, hi, lo, if (up) bodyBot else bodyTop, if (up) bodyTop else bodyBot))
        }
        out.sortBy { it.x }
        if (out.size >= 10 && !regular(out)) return ArrayList()
        return if (out.size > 60) ArrayList(out.subList(out.size - 60, out.size)) else out
    }

    /** Real candles are evenly spaced. Random green/red shapes (photos, icons) are not. */
    private fun regular(c: List<Candle>): Boolean {
        val d = ArrayList<Float>()
        for (i in 1 until c.size) d.add(c[i].x - c[i - 1].x)
        val md = d.sorted()[d.size / 2]
        if (md < 3f) return false
        var ok = 0
        for (x in d) {
            val k = max(1, Math.round(x / md))
            if (abs(x - k * md) <= 0.25f * md) ok++
        }
        return ok >= d.size * 0.75
    }

    private fun ema(v: List<Double>, p: Int): List<Double> {
        val k = 2.0 / (p + 1)
        val o = ArrayList<Double>()
        var e = v[0]
        for (x in v) {
            e = x * k + e * (1 - k)
            o.add(e)
        }
        return o
    }

    /** Scores one frame. Positive = UP, negative = DOWN. */
    fun evaluate(cs: List<Candle>): Eval? {
        if (cs.size < 10) return null
        val n = cs.size
        val H = DoubleArray(n) { cs[it].high.toDouble() }
        val L = DoubleArray(n) { cs[it].low.toDouble() }
        val O = DoubleArray(n) { cs[it].open.toDouble() }
        val C = DoubleArray(n) { cs[it].close.toDouble() }
        val U = BooleanArray(n) { cs[it].up }
        val close = C.toList()
        val st14 = max(0, n - 14)
        var rsum = 0.0
        for (i in st14 until n) rsum += H[i] - L[i]
        val atr = max(2.0, rsum / (n - st14))

        // market regime: trending (efficiency ratio high) or ranging (low)
        val kk = min(14, n - 1)
        var net = abs(C[n - 1] - C[n - 1 - kk])
        var path = 0.0
        for (i in n - kk until n) path += abs(C[i] - C[i - 1])
        val er = if (path > 0) net / path else 0.0
        val regime = if (er >= 0.4) 1 else if (er <= 0.22) -1 else 0

        val items = ArrayList<Item>()
        val flags = ArrayList<String>()
        val gs = DoubleArray(4)
        var unc = 0.0
        fun add(key: String, label: String, v: Double) {
            val g = groupOf(key)
            var mult = weights[key] ?: 1.0
            if (regime == 1) {
                if (g == 0) mult *= 1.25 else if (g == 1) mult *= 0.6
            } else if (regime == -1) {
                if (g == 0) mult *= 0.6 else if (g == 1) mult *= 1.3
            }
            val x = v * mult
            if (x != 0.0) {
                items.add(Item(key, label, x))
                gs[g] += x
            }
        }
        fun bd(i: Int): Double = abs(C[i] - O[i])

        // 1) trend (regression of last 12 closes)
        val m = min(12, n)
        val ys = close.takeLast(m)
        val xm = (m - 1) / 2.0
        val ym = ys.average()
        var num = 0.0
        var den = 0.0
        for (i in 0 until m) {
            num += (i - xm) * (ys[i] - ym)
            den += (i - xm) * (i - xm)
        }
        val slope = if (den == 0.0) 0.0 else num / den
        val trend = (slope / atr * 3.0).coerceIn(-2.0, 2.0)
        add("trend", if (trend > 0) "Uptrend" else "Downtrend", trend)

        // 2) EMA cross
        val e5 = ema(close, 5)
        val e13 = ema(close, 13)
        val ed = ((e5.last() - e13.last()) / atr * 2.0).coerceIn(-1.5, 1.5)
        add("ema", if (ed > 0) "EMA cross up" else "EMA cross down", ed)

        // 3) RSI
        val p = min(14, n - 1)
        var gain = 0.0
        var loss = 0.0
        for (i in n - p until n) {
            val d = C[i] - C[i - 1]
            if (d > 0) gain += d else loss -= d
        }
        val rsi = if (gain == 0.0 && loss == 0.0) 50.0 else if (loss == 0.0) 100.0 else 100.0 - 100.0 / (1.0 + gain / loss)
        val rv = when {
            rsi >= 75 -> -1.2
            rsi <= 25 -> 1.2
            rsi in 55.0..75.0 -> 0.3
            rsi in 25.0..45.0 -> -0.3
            else -> 0.0
        }
        add("rsi", "RSI ${rsi.toInt()}" + (if (rv > 0) " (bullish)" else " (bearish)"), rv)

        // 4) MACD
        if (n >= 26) {
            val e12 = ema(close, 12)
            val e26 = ema(close, 26)
            val ml = e12.indices.map { e12[it] - e26[it] }
            val sg = ema(ml, 9)
            val h1 = ml[n - 1] - sg[n - 1]
            val h0 = ml[n - 2] - sg[n - 2]
            val mv = (if (h1 > 0) 0.6 else -0.6) + (if (h1 > h0) 0.4 else -0.4)
            add("macd", if (mv > 0) "MACD bullish" else "MACD bearish", mv)
        }

        // 5) Bollinger
        val bw = close.takeLast(min(20, n))
        val sma = bw.average()
        val sd = sqrt(bw.map { (it - sma) * (it - sma) }.average())
        if (sd > 0.5) {
            val z = (C[n - 1] - sma) / sd
            if (abs(z) > 1.9) add("boll", if (z > 0) "Bollinger upper band (reversal risk)" else "Bollinger lower band (reversal risk)", -sign(z))
            else add("boll", if (z > 0) "Price above mid-band" else "Price below mid-band", z * 0.35)
        }

        // 6) momentum of last 3 candles
        val mom = ((C[n - 1] - C[n - 4]) / atr * 0.7).coerceIn(-1.5, 1.5)
        add("mom", if (mom > 0) "Momentum up (3 candles)" else "Momentum down (3 candles)", mom)

        // 7) last candle shape
        val a = n - 1
        val b = n - 2
        val c3 = n - 3
        val body = bd(a)
        val rng = max(1.0, H[a] - L[a])
        val uw = H[a] - max(O[a], C[a])
        val lw = min(O[a], C[a]) - L[a]
        val dir = if (U[a]) 1.0 else -1.0
        var doji = false
        if (rng >= 0.5 * atr) {
            if (lw >= 0.55 * rng && body <= 0.35 * rng) {
                add("hammer", "Hammer (long lower wick)", if (trend < 0) 1.9 else 1.4)
            } else if (uw >= 0.55 * rng && body <= 0.35 * rng) {
                add("star", "Shooting Star (long upper wick)", if (trend > 0) -1.9 else -1.4)
            } else if (body <= 0.1 * rng) {
                doji = true
            } else if (uw >= 0.4 * rng) {
                add("wick", "Long upper wick (selling pressure)", -0.7)
            } else if (lw >= 0.4 * rng) {
                add("wick", "Long lower wick (buying pressure)", 0.7)
            }
            if (body >= 0.7 * rng && body >= 1.2 * atr) add("maru", if (U[a]) "Strong green candle" else "Strong red candle", 0.8 * dir)
        }

        // bigger trend over the whole visible chart + pullback entries inside a trend
        val mb = min(40, n)
        val yb = close.takeLast(mb)
        val xmb = (mb - 1) / 2.0
        val ymb = yb.average()
        var nb = 0.0
        var db = 0.0
        for (i in 0 until mb) {
            nb += (i - xmb) * (yb[i] - ymb)
            db += (i - xmb) * (i - xmb)
        }
        val bslope = if (db == 0.0) 0.0 else nb / db
        add("btrend", if (bslope > 0) "Bigger trend up" else "Bigger trend down", (bslope / atr * 4.0).coerceIn(-1.5, 1.5))
        if (regime == 1 && n >= 20) {
            val td = if (bslope > 0) 1.0 else -1.0
            if (dir != td && body < 0.9 * atr) add("pullback", if (td > 0) "Pullback in uptrend" else "Pullback in downtrend", td * 0.9)
        }

        // 8) two-candle patterns
        val tol = 0.1 * atr
        if (!U[b] && U[a] && C[a] >= O[b] - tol && O[a] <= C[b] + tol && body > bd(b)) add("engulf", "Bullish Engulfing", 1.5)
        if (U[b] && !U[a] && C[a] <= O[b] + tol && O[a] >= C[b] - tol && body > bd(b)) add("engulf", "Bearish Engulfing", -1.5)
        val bTop = max(O[b], C[b])
        val bBot = min(O[b], C[b])
        val aTop = max(O[a], C[a])
        val aBot = min(O[a], C[a])
        val bMid = (O[b] + C[b]) / 2.0
        if (bd(b) >= 0.8 * atr && body <= 0.5 * bd(b) && aTop <= bTop && aBot >= bBot) add("harami", "Harami", if (!U[b]) 0.8 else -0.8)
        if (!U[b] && bd(b) >= 0.8 * atr && U[a] && O[a] < C[b] && C[a] > bMid && C[a] < O[b]) add("piercing", "Piercing Line", 1.0)
        if (U[b] && bd(b) >= 0.8 * atr && !U[a] && O[a] > C[b] && C[a] < bMid && C[a] > O[b]) add("piercing", "Dark Cloud Cover", -1.0)
        if (abs(H[b] - H[a]) <= 0.15 * atr && U[b] && !U[a]) add("tweezer", "Tweezer Top", -1.0)
        if (abs(L[b] - L[a]) <= 0.15 * atr && !U[b] && U[a]) add("tweezer", "Tweezer Bottom", 1.0)
        if (H[a] < H[b] && L[a] > L[b]) unc += 0.5

        // 9) three-candle patterns
        val mid3 = (O[c3] + C[c3]) / 2.0
        if (!U[c3] && bd(c3) >= 0.8 * atr && bd(b) <= 0.3 * bd(c3) && U[a] && C[a] > mid3) add("morning", "Morning Star", 1.6)
        if (U[c3] && bd(c3) >= 0.8 * atr && bd(b) <= 0.3 * bd(c3) && !U[a] && C[a] < mid3) add("evening", "Evening Star", -1.6)
        if (U[a] && U[b] && U[c3] && C[a] > C[b] && C[b] > C[c3] && bd(a) >= 0.5 * atr && bd(b) >= 0.5 * atr && bd(c3) >= 0.5 * atr) add("soldiers", "Three White Soldiers", 1.4)
        if (!U[a] && !U[b] && !U[c3] && C[a] < C[b] && C[b] < C[c3] && bd(a) >= 0.5 * atr && bd(b) >= 0.5 * atr && bd(c3) >= 0.5 * atr) add("soldiers", "Three Black Crows", -1.4)

        // 10) streak
        var st = 0
        for (i in n - 1 downTo 0) {
            if (U[i] == U[a]) st++ else break
        }
        if (st >= 6) add("streak", "$st same-color candles (reversal risk)", -dir * 0.8)
        else if (st >= 2) add("streak", "$st candles in a row", dir * 0.2 * st)

        // 11) market structure (swing points)
        val sh = ArrayList<Int>()
        val sl = ArrayList<Int>()
        for (i in max(2, n - 40) until n - 2) {
            if (H[i] > H[i - 1] && H[i] > H[i - 2] && H[i] > H[i + 1] && H[i] > H[i + 2]) sh.add(i)
            if (L[i] < L[i - 1] && L[i] < L[i - 2] && L[i] < L[i + 1] && L[i] < L[i + 2]) sl.add(i)
        }
        val last = C[n - 1]
        if (sh.size >= 2 && sl.size >= 2) {
            val hh = H[sh[sh.size - 1]] > H[sh[sh.size - 2]]
            val hl = L[sl[sl.size - 1]] > L[sl[sl.size - 2]]
            if (hh && hl) add("struct", "HH + HL (up structure)", 1.2)
            else if (!hh && !hl) add("struct", "LH + LL (down structure)", -1.2)
        }
        if (sh.size >= 2) {
            val i1 = sh[sh.size - 1]
            val i2 = sh[sh.size - 2]
            val lvl = min(H[i1], H[i2])
            if (i1 - i2 >= 3 && abs(H[i1] - H[i2]) <= 0.35 * atr && last < lvl && last > lvl - 1.5 * atr) add("dbl", "Double Top", -1.0)
        }
        if (sl.size >= 2) {
            val i1 = sl[sl.size - 1]
            val i2 = sl[sl.size - 2]
            val lvl = max(L[i1], L[i2])
            if (i1 - i2 >= 3 && abs(L[i1] - L[i2]) <= 0.35 * atr && last > lvl && last < lvl + 1.5 * atr) add("dbl", "Double Bottom", 1.0)
        }

        // 12) support / resistance and how often they were touched
        if (n >= 12) {
            val from = max(0, n - 40)
            var res = -1e18
            var sup = 1e18
            for (i in from until n - 2) {
                res = max(res, H[i])
                sup = min(sup, L[i])
            }
            var tr = 0
            var ts = 0
            for (i in from until n - 2) {
                if (abs(H[i] - res) <= 0.3 * atr) tr++
                if (abs(L[i] - sup) <= 0.3 * atr) ts++
            }
            val near = 0.7 * atr
            if (last >= res - near && last <= res + 0.2 * atr) {
                add("sr", "Near resistance", -1.0)
                if (tr >= 3) add("touches", "Strong resistance ($tr touches)", -0.5)
            } else if (last > res + 0.2 * atr) add("sr", "Resistance breakout", 0.8)
            if (last <= sup + near && last >= sup - 0.2 * atr) {
                add("sr", "Near support", 1.0)
                if (ts >= 3) add("touches", "Strong support ($ts touches)", 0.5)
            } else if (last < sup - 0.2 * atr) add("sr", "Support breakdown", -0.8)
        }

        // 13) Stochastic, CCI, Williams %R
        if (n >= 16) {
            fun stochK(end: Int): Double {
                var hi = -1e18
                var lo = 1e18
                for (i in end - 13..end) {
                    hi = max(hi, H[i])
                    lo = min(lo, L[i])
                }
                return if (hi == lo) 50.0 else (C[end] - lo) / (hi - lo) * 100.0
            }
            val k0 = stochK(n - 1)
            val dd = (stochK(n - 1) + stochK(n - 2) + stochK(n - 3)) / 3.0
            if (k0 > 80 && k0 < dd) add("stoch", "Stochastic overbought", -0.6)
            else if (k0 < 20 && k0 > dd) add("stoch", "Stochastic oversold", 0.6)

            val tp = DoubleArray(14) { (H[n - 14 + it] + L[n - 14 + it] + C[n - 14 + it]) / 3.0 }
            val tpm = tp.average()
            var md = 0.0
            for (x in tp) md += abs(x - tpm)
            md /= 14.0
            if (md > 0.3) {
                val cci = (tp[13] - tpm) / (0.015 * md)
                if (cci > 150) add("cci", "CCI overbought", -0.4)
                else if (cci < -150) add("cci", "CCI oversold", 0.4)
            }

            var hi14 = -1e18
            var lo14 = 1e18
            for (i in n - 14 until n) {
                hi14 = max(hi14, H[i])
                lo14 = min(lo14, L[i])
            }
            if (hi14 > lo14) {
                val wr = -100.0 * (hi14 - C[n - 1]) / (hi14 - lo14)
                if (wr > -10) add("willr", "Williams %R overbought", -0.4)
                else if (wr < -90) add("willr", "Williams %R oversold", 0.4)
            }
        }

        // 14) Fibonacci retracement of the recent swing
        if (n >= 12) {
            val from = max(0, n - 40)
            var hi = -1e18
            var lo = 1e18
            var hiI = from
            var loI = from
            for (i in from until n) {
                if (H[i] > hi) { hi = H[i]; hiI = i }
                if (L[i] < lo) { lo = L[i]; loI = i }
            }
            val rg = hi - lo
            if (rg >= 3 * atr) {
                for (r in doubleArrayOf(0.382, 0.5, 0.618)) {
                    if (loI < hiI) {
                        val lv = hi - r * rg
                        if (abs(last - lv) <= 0.25 * atr) { add("fib", "Fibonacci support", 0.6); break }
                    } else if (hiI < loI) {
                        val lv = lo + r * rg
                        if (abs(last - lv) <= 0.25 * atr) { add("fib", "Fibonacci resistance", -0.6); break }
                    }
                }
            }
        }

        // 15) filters
        var hi20 = -1e18
        var lo20 = 1e18
        for (i in max(0, n - 20) until n) {
            hi20 = max(hi20, H[i])
            lo20 = min(lo20, L[i])
        }
        if (hi20 - lo20 < 3.5 * atr) flags.add("Flat market")
        var flips = 0
        for (i in max(1, n - 12) until n) if (U[i] != U[i - 1]) flips++
        if (flips >= 8) flags.add("Choppy market")
        if (doji) {
            flags.add("Doji candle")
            unc += 1.0
        }

        // each family is capped, so one family of similar indicators cannot dominate
        val gsc = DoubleArray(4) { gs[it].coerceIn(-CAPS[it], CAPS[it]) }
        var total = 0.0
        for (x in gsc) total += x
        return Eval(total, CAPS.sum() + unc, items, flags, gsc)
    }

    fun combine(evals: List<Eval>, candleCount: Int): Verdict {
        val n = evals.size
        val g = DoubleArray(4)
        var tot = 0.0
        var wsum = 0.0
        for ((i, e) in evals.withIndex()) {
            val w = 0.5 + i.toDouble() / max(1, n - 1) // newer frames count more
            wsum += w
            tot += e.total * w
            for (k in 0..3) g[k] += e.groups[k] * w
        }
        tot /= wsum
        for (k in 0..3) g[k] /= wsum
        val up = tot >= 0
        val m = abs(tot) / CAPS.sum()

        var aligned = 0
        var opposed = 0
        for (k in 0..3) {
            if (abs(g[k]) >= 0.5) {
                if ((g[k] >= 0) == up) aligned++ else opposed++
            }
        }
        val agreeG = if (aligned + opposed == 0) 0.0 else aligned.toDouble() / (aligned + opposed)
        val frameAgree = evals.count { (it.total >= 0) == up }.toDouble() / n

        val warn = ArrayList<String>()
        for (f in listOf("Flat market", "Choppy market", "Doji candle")) {
            if (evals.count { it.flags.contains(f) } * 2 > n) warn.add(f)
        }
        var strength = m * (0.4 + 0.6 * agreeG) * (0.5 + 0.5 * frameAgree)
        if (warn.isNotEmpty()) strength *= 0.85
        val conf = (25 + 90 * strength).toInt().coerceIn(20, 92)
        if (agreeG < 0.6) warn.add("Indicators disagree")

        val sorted = evals.last().items.sortedByDescending { abs(it.v) }
        val alignedItems = sorted.filter { it.v != 0.0 && (it.v >= 0) == up }
        return Verdict(up, conf, alignedItems.take(3).map { it.label }, candleCount, alignedItems.map { it.key }.distinct(), warn, false)
    }
}
