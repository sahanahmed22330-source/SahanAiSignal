package com.sahan.aisignal

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max

class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false

        private val WHITE = 0xFFFFFFFF.toInt()
        private val GREEN = 0xFF00E676.toInt()
        private val RED = 0xFFFF5252.toInt()
        private val CYAN = 0xFF00E5FF.toInt()
        private val AMBER = 0xFFFFB300.toInt()
        private val BLUE = 0xFF2D8CFF.toInt()
        private val DARK = 0xF0071A17.toInt()
        private val NAVY = 0xF0061436.toInt()
    }

    private class Frame(
        val pix: IntArray, val w: Int, val h: Int, val ignore: List<Rect>,
        val lower: IntArray?, val lw: Int, val lh: Int
    )

    private class Sample(val t: Long, val ev: Eval, val n: Int)

    private class Ocr {
        val latch = CountDownLatch(1)

        @Volatile
        var text: String = ""
    }

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val watcher = Executors.newSingleThreadExecutor()
    private val buf = ArrayList<Sample>()
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var sw = 0
    private var sh = 0

    private var root: LinearLayout? = null
    private var rootLp: WindowManager.LayoutParams? = null
    private var ringV: View? = null
    private var timerTv: TextView? = null
    private var chip: TextView? = null
    private var chipState = -1
    private var chipHiddenFor = -1
    private var realState = -1
    private var startedAt = 0L
    private var box: LinearLayout? = null
    private var l1: TextView? = null
    private var l2: TextView? = null
    private var l3: TextView? = null
    private var l4: TextView? = null

    private var cache: Frame? = null
    private var lastAutoStart = -1L
    private var tickN = 0
    private var ringState = -1

    @Volatile
    private var lastExpiry = -1

    @Volatile
    private var lastN = 0

    @Volatile
    private var lastGoodAt = 0L

    @Volatile
    private var scanning = false

    @Volatile
    private var captureLost = false

    @Volatile
    private var marketBad = false

    @Volatile
    private var ignoreResult = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra("data", Intent::class.java)
        else i?.getParcelableExtra("data")

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = readData(intent)
        if (running) {
            // permission granted again after the capture was stopped
            startFg()
            if (data != null && captureLost) {
                try {
                    initCapture(code, data)
                    cache = null
                    synchronized(buf) { buf.clear() }
                    captureLost = false
                } catch (e: Throwable) {
                    Toast.makeText(this, "Screen capture failed: " + e.message, Toast.LENGTH_LONG).show()
                }
            }
            return START_NOT_STICKY
        }
        startFg()
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            screenSize()
            initCapture(code, data)
            startedAt = SystemClock.uptimeMillis()
            createButton()
            running = true
            ui.post(tick)
            watcher.execute { watchLoop() }
        } catch (e: Throwable) {
            Toast.makeText(this, "Screen capture failed: " + e.message, Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun initCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                ui.post { onCaptureLost(mp) }
            }
        }, ui)
        projection = mp
        val rd = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        reader = rd
        vd = mp.createVirtualDisplay(
            "sahan_ai", sw, sh, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, null
        )
    }

    /** Capture was stopped by the system or another recorder: keep the button, ask to restart. */
    private fun onCaptureLost(mp: MediaProjection) {
        if (mp !== projection) return
        captureLost = true
        try { vd?.release() } catch (e: Exception) { }
        vd = null
        try { reader?.close() } catch (e: Exception) { }
        reader = null
        projection = null
        cache = null
        synchronized(buf) { buf.clear() }
        lastGoodAt = 0L
        marketBad = false
        hideBox()
    }

    private fun restartCapture() {
        try {
            val i = Intent(this, CaptureActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Throwable) {
            Toast.makeText(this, "Open the Sahan Ai Signal app and tap START again", Toast.LENGTH_LONG).show()
        }
    }

    private fun startFg() {
        val ch = "sahan_ai"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(ch, "Sahan Ai Signal", NotificationManager.IMPORTANCE_LOW))
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this)
        val n = b.setContentTitle("Sahan Ai Signal is running")
            .setContentText("AI is watching the chart. Tap the floating button for a signal.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    @Suppress("DEPRECATION")
    private fun screenSize() {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            sw = b.width()
            sh = b.height()
        } else {
            val m = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(m)
            sw = m.widthPixels
            sh = m.heightPixels
        }
    }

    @Suppress("DEPRECATION")
    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    // ---------------------------------------------------------------- floating widget

    private fun drag(v: View, lp: WindowManager.LayoutParams, onTap: (() -> Unit)?) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = ox + dx.toInt()
                        lp.y = oy + dy.toInt()
                        try { wm.updateViewLayout(v, lp) } catch (ex: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke()
                    true
                }
                else -> false
            }
        }
    }

    private fun createButton() {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.gravity = Gravity.CENTER_HORIZONTAL

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        // logo + status ring + candle timer
        val rb = FrameLayout(this)
        val ring = View(this)
        rb.addView(ring, FrameLayout.LayoutParams(dp(72), dp(72), Gravity.TOP or Gravity.START))
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        val llp = FrameLayout.LayoutParams(dp(58), dp(58), Gravity.TOP or Gravity.START)
        llp.leftMargin = dp(7)
        llp.topMargin = dp(7)
        rb.addView(logo, llp)
        val t = tv("--", 11f, WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(7), 0, dp(7), 0)
        t.background = rounded(0xDD0B1030.toInt(), dp(9).toFloat())
        rb.addView(t, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, dp(18), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        top.addView(rb, LinearLayout.LayoutParams(dp(72), dp(78)))

        // X button
        val x = tv("✕", 14f, WHITE, true)
        x.gravity = Gravity.CENTER
        x.background = rounded(0xDD4A4F5A.toInt(), dp(15).toFloat(), dp(1), 0x66FFFFFF)
        x.setOnClickListener {
            if (box?.visibility == View.VISIBLE) hideBoxByUser()
            else if (chip?.visibility == View.VISIBLE) dismissChip()
            else stopSelf()
        }
        val xlp = LinearLayout.LayoutParams(dp(30), dp(30))
        xlp.leftMargin = dp(6)
        top.addView(x, xlp)

        // signal box
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        b.gravity = Gravity.CENTER
        b.setPadding(dp(16), dp(8), dp(16), dp(8))
        b.visibility = View.GONE
        val a1 = tv("", 20f, WHITE, true)
        val a2 = tv("", 24f, WHITE, true)
        val a3 = tv("", 11f, AMBER, true)
        val a4 = tv("", 11f, RED, true)
        for (q in listOf(a1, a2, a3, a4)) {
            q.gravity = Gravity.CENTER
            b.addView(q)
        }
        b.setOnClickListener { hideBoxByUser() }
        val blp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        blp.topMargin = dp(2)

        val ch = tv("", 11f, WHITE, true)
        ch.gravity = Gravity.CENTER
        ch.setPadding(dp(10), dp(5), dp(10), dp(5))
        ch.visibility = View.GONE
        ch.setOnClickListener { dismissChip() }
        val clp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        clp.topMargin = dp(2)

        r.addView(top, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        r.addView(ch, clp)
        r.addView(b, blp)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = (sh * 0.30).toInt()
        drag(r, lp) { if (captureLost) restartCapture() else if (!scanning) startScan() }
        wm.addView(r, lp)

        root = r
        rootLp = lp
        ringV = ring
        chip = ch
        timerTv = t
        box = b
        l1 = a1
        l2 = a2
        l3 = a3
        l4 = a4
    }

    private fun showBox(t1: String, t2: String?, t3: String?, t4: String?, color: Int, fill: Int) {
        val b = box ?: return
        l1?.text = t1
        l1?.setTextColor(color)
        l2?.text = t2 ?: ""
        l2?.setTextColor(color)
        l2?.visibility = if (t2 == null) View.GONE else View.VISIBLE
        l3?.text = t3 ?: ""
        l3?.visibility = if (t3 == null) View.GONE else View.VISIBLE
        l4?.text = t4 ?: ""
        l4?.visibility = if (t4 == null) View.GONE else View.VISIBLE
        b.background = rounded(fill, dp(18).toFloat(), dp(2), color)
        b.visibility = View.VISIBLE
    }

    /** Hide the status chip until the state changes (e.g. blue -> amber). */
    private fun dismissChip() {
        chipHiddenFor = realState
        chipState = 3
        chip?.visibility = View.GONE
    }

    private fun hideBox() {
        box?.visibility = View.GONE
    }

    private fun hideBoxByUser() {
        if (scanning) ignoreResult = true
        hideBox()
    }

    private fun fmtShort(sec: Int): String = if (sec >= 60 && sec % 60 == 0) "${sec / 60}m" else "${sec}s"

    private fun showResult(v: Verdict?, expirySec: Int, tf: Int) {
        if (v == null) {
            showBox("NO CHART", null, "Open the candle chart", null, RED, DARK)
            return
        }
        val mismatch = if (expirySec > 0 && expirySec != tf) "⚠ Quotex ${fmtShort(expirySec)} ≠ App ${fmtShort(tf)}" else null
        if (v.change) {
            showBox("CHANGE", "MARKET", "No clear signal here", mismatch, AMBER, DARK)
            return
        }
        val weak = v.confidence < 50
        val color = if (weak) AMBER else if (v.up) GREEN else RED
        showBox(
            if (v.up) "UP ▲" else "DOWN ▼",
            "${v.confidence}%",
            if (weak) "WEAK - SKIP" else null,
            mismatch, color, DARK
        )
    }

    // ---------------------------------------------------------------- timing

    private fun scanMs(tf: Int): Long = when {
        tf <= 5 -> 2500L
        tf <= 10 -> 3000L
        else -> 3500L
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            tickN++
            val ctx = this@OverlayService
            val tf = Store.tf(ctx)
            val tfMs = tf * 1000L
            val now = System.currentTimeMillis() + Store.offset(ctx) * 100L
            val pos = now % tfMs
            val rem = tfMs - pos
            val start = now - pos

            timerTv?.text = if (tfMs <= 10000L) String.format(Locale.US, "%.1fs", rem / 1000.0)
            else String.format(Locale.US, "%d:%02d", rem / 60000, (rem / 1000) % 60)

            val ok = SystemClock.uptimeMillis() - lastGoodAt < 2500
            val st = if (ok) 1 else 0
            if (st != ringState) {
                ringState = st
                ringV?.background = rounded(0xFF0B1030.toInt(), dp(36).toFloat(), dp(4), if (ok) BLUE else RED)
            }

            val boxShown = box?.visibility == View.VISIBLE
            val real = when {
                captureLost -> 5
                boxShown -> 3
                !ok && SystemClock.uptimeMillis() - startedAt < 3000 -> 0
                !ok -> 2
                marketBad -> 4
                else -> 1
            }
            if (real != 3 && real != chipHiddenFor) chipHiddenFor = -1
            realState = real
            val cst = if (real == chipHiddenFor) 3 else real
            if (cst != chipState) {
                chipState = cst
                val c = chip
                if (c != null) {
                    when (cst) {
                        0 -> {
                            c.text = "STARTING..."
                            c.setTextColor(0xFFB0BEC5.toInt())
                            c.background = rounded(DARK, dp(12).toFloat(), dp(2), 0xFFB0BEC5.toInt())
                            c.visibility = View.VISIBLE
                        }
                        1 -> {
                            c.text = "● ANALYZING MARKET"
                            c.setTextColor(BLUE)
                            c.background = rounded(DARK, dp(12).toFloat(), dp(2), BLUE)
                            c.visibility = View.VISIBLE
                        }
                        2 -> {
                            c.text = "✖ CAN'T SEE MARKET\nOpen the candle chart"
                            c.setTextColor(RED)
                            c.background = rounded(DARK, dp(12).toFloat(), dp(2), RED)
                            c.visibility = View.VISIBLE
                        }
                        4 -> {
                            c.text = "CHANGE MARKET\nNo clear signal here"
                            c.setTextColor(AMBER)
                            c.background = rounded(DARK, dp(12).toFloat(), dp(2), AMBER)
                            c.visibility = View.VISIBLE
                        }
                        5 -> {
                            c.text = "SCREEN CAPTURE STOPPED\nTap the button to restart"
                            c.setTextColor(RED)
                            c.background = rounded(DARK, dp(12).toFloat(), dp(2), RED)
                            c.visibility = View.VISIBLE
                        }
                        else -> c.visibility = View.GONE
                    }
                }
            }

            if (scanning && !ignoreResult) {
                l1?.text = "ANALYZING" + ".".repeat(1 + (tickN / 4) % 3)
            }

            if (Store.auto(ctx) && !scanning) {
                val trigger = scanMs(tf) + 1200L
                if (rem <= trigger && rem > 300L && start != lastAutoStart) {
                    lastAutoStart = start
                    startScan()
                }
            }
            ui.postDelayed(this, 100)
        }
    }

    // ---------------------------------------------------------------- capture

    private fun readRegion(img: Image, x0: Int, y0: Int, w: Int, h: Int): IntArray {
        val pl = img.planes[0]
        val buf = pl.buffer
        val rs = pl.rowStride
        val ps = pl.pixelStride
        val out = IntArray(w * h)
        val row = ByteArray(w * ps)
        for (r in 0 until h) {
            buf.position((y0 + r) * rs + x0 * ps)
            buf.get(row, 0, w * ps)
            var o = r * w
            var i = 0
            for (c in 0 until w) {
                out[o++] = (0xFF shl 24) or
                    ((row[i].toInt() and 0xFF) shl 16) or
                    ((row[i + 1].toInt() and 0xFF) shl 8) or
                    (row[i + 2].toInt() and 0xFF)
                i += ps
            }
        }
        return out
    }

    private fun grab(topPct: Int, botPct: Int, rects: List<Rect>, wantLower: Boolean): Frame? {
        val r = reader ?: return null
        var img: Image? = null
        val end = SystemClock.uptimeMillis() + 600
        while (img == null && SystemClock.uptimeMillis() < end) {
            img = try { r.acquireLatestImage() } catch (e: Exception) { null }
            if (img == null) Thread.sleep(25)
        }
        if (img == null) return cache
        try {
            val iw = img.width
            val ih = img.height
            val cw = (iw * 0.86).toInt()
            val y0 = ih * topPct / 100
            val y1 = ih * botPct / 100
            val ch = (y1 - y0).coerceAtLeast(60)
            val pix = readRegion(img, 0, y0, cw, ch)
            var lower: IntArray? = null
            var lw = 0
            var lh = 0
            if (wantLower) {
                // trade panel (Time / Timer field), left half, just under the chart
                val ly = (ih * 0.72).toInt()
                lw = (iw * 0.55).toInt()
                lh = (ih * 0.18).toInt()
                lower = readRegion(img, 0, ly, lw, lh)
            }
            val ig = rects.map { Rect(it.left, it.top - y0, it.right, it.bottom - y0) }
            val f = Frame(pix, cw, ch, ig, lower, lw, lh)
            cache = f
            return f
        } finally {
            img.close()
        }
    }

    private fun startOcr(px: IntArray, w: Int, h: Int): Ocr {
        val o = Ocr()
        try {
            val bmp = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                .process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener {
                    o.text = it.text
                    o.latch.countDown()
                }
                .addOnFailureListener { o.latch.countDown() }
        } catch (e: Throwable) {
            o.latch.countDown()
        }
        return o
    }

    /**
     * Quotex "Timer" field shows 00:00:10 (a duration).
     * Quotex "Time" field shows a clock time like 18:40 (expires at a minute boundary -> treated as 1 minute).
     * Returns seconds, or -1 when nothing could be read.
     */
    private fun parseExpiry(t: String): Int {
        val hms = Regex("""(\d{1,2}):(\d{2}):(\d{2})""").find(t)
        if (hms != null) {
            val sec = hms.groupValues[1].toInt() * 3600 + hms.groupValues[2].toInt() * 60 + hms.groupValues[3].toInt()
            if (sec in 3..14400) return sec
        }
        val hm = Regex("""(\d{1,2}):(\d{2})""").find(t)
        if (hm != null) {
            val h = hm.groupValues[1].toInt()
            val m = hm.groupValues[2].toInt()
            if (h < 24 && m < 60) return 60
        }
        return -1
    }

    private fun buttonRect(): Rect {
        val l = rootLp ?: return Rect(0, 0, 0, 0)
        val r = root
        val w = if (r != null && r.width > 0) r.width else dp(120)
        val h = if (r != null && r.height > 0) r.height else dp(150)
        return Rect(l.x - dp(4), l.y - dp(4), l.x + w + dp(4), l.y + h + dp(4))
    }

    /** Runs all the time: reads the chart ~3 times a second and keeps the latest results. */
    private fun watchLoop() {
        var lastOcrAt = 0L
        var pending: Ocr? = null
        var lastFrame: Frame? = null
        var lastW = 0L
        var badCount = 0
        var goodCount = 0
        while (running) {
            try {
                val now = SystemClock.uptimeMillis()
                if (now - lastW > 5000) {
                    Analyzer.weights = Store.weights(this)
                    lastW = now
                }
                val wantLower = pending == null && now - lastOcrAt > 3000
                val rects = ArrayList<Rect>()
                rects.add(buttonRect())
                val f = grab(Store.top(this), Store.bottom(this), rects, wantLower)
                if (f != null && f !== lastFrame) {
                    lastFrame = f
                    val lo = f.lower
                    if (lo != null && f.lw > 0 && f.lh > 0) {
                        pending = startOcr(lo, f.lw, f.lh)
                        lastOcrAt = now
                    }
                    val cs = Analyzer.extract(f.pix, f.w, f.h, f.ignore)
                    lastN = cs.size
                    if (cs.size >= 10) lastGoodAt = SystemClock.uptimeMillis()
                    val ev = Analyzer.evaluate(cs)
                    if (ev != null) {
                        synchronized(buf) {
                            buf.add(Sample(now, ev, cs.size))
                            while (buf.size > 60) buf.removeAt(0)
                        }
                        // judge the market quality by itself, no tap needed
                        val recent: List<Sample> = synchronized(buf) { buf.filter { now - it.t <= 8000 } }
                        if (recent.size >= 8) {
                            val bad = Analyzer.combine(recent.map { it.ev }, recent.last().n).change
                            if (bad) { badCount++; goodCount = 0 } else { goodCount++; badCount = 0 }
                            if (badCount >= 5) marketBad = true else if (goodCount >= 5) marketBad = false
                        }
                    }
                }
                val p = pending
                if (p != null && p.latch.count == 0L) {
                    lastExpiry = parseExpiry(p.text)
                    pending = null
                }
                Thread.sleep(300)
            } catch (e: InterruptedException) {
                return
            } catch (e: Throwable) {
                try { Thread.sleep(500) } catch (x: InterruptedException) { return }
            }
        }
    }

    /** Button tap: analyze for 3-4 more seconds, then combine with what the AI already watched. */
    private fun startScan() {
        if (scanning || captureLost) return
        scanning = true
        ignoreResult = false
        val tf = Store.tf(this)
        val sd = scanMs(tf)
        showBox("ANALYZING.", null, null, null, CYAN, NAVY)

        worker.execute {
            var verdict: Verdict? = null
            try {
                Thread.sleep(sd)
                val now = SystemClock.uptimeMillis()
                var used: List<Sample> = synchronized(buf) { buf.filter { now - it.t <= sd + 4000 } }
                if (used.isEmpty()) used = synchronized(buf) { buf.takeLast(3) }
                if (used.isNotEmpty()) verdict = Analyzer.combine(used.map { it.ev }, used.last().n)
            } catch (e: InterruptedException) {
                return@execute
            } catch (e: Throwable) {
                verdict = null
            }
            val fv = verdict
            val fx = lastExpiry
            ui.post {
                scanning = false
                val ign = ignoreResult
                ignoreResult = false
                if (running && !ign) {
                    if (fv != null) Store.add(this, Rec(System.currentTimeMillis(), tf, fv.up, fv.confidence, 0, fv.keys.joinToString(",")))
                    showResult(fv, fx, tf)
                }
            }
        }
    }

    override fun onDestroy() {
        running = false
        ui.removeCallbacksAndMessages(null)
        root?.let {
            try { wm.removeView(it) } catch (e: Exception) { }
        }
        root = null
        try { vd?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        worker.shutdownNow()
        watcher.shutdownNow()
        super.onDestroy()
    }
}
